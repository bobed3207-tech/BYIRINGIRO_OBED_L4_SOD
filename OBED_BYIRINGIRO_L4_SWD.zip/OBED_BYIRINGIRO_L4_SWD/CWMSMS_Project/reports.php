<?php
session_start();
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
require_once 'config/db.php';

$date = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');

$query = "SELECT c.PlateNumber, p.PackageName, p.PackageDescription, pay.AmountPaid, pay.PaymentDate
          FROM ServicePackage sp
          JOIN Car c ON sp.PlateNumber = c.PlateNumber
          JOIN Package p ON sp.PackageNumber = p.PackageNumber
          JOIN Payment pay ON sp.RecordNumber = pay.RecordNumber
          WHERE DATE(pay.PaymentDate) = '$date'";
          
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Car Wash System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { min-height: 100vh; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); }
        .header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); padding: 25px 50px; color: white; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 24px; font-weight: 700; }
        .user-info { display: flex; align-items: center; gap: 10px; }
        .user-info .avatar { width: 40px; height: 40px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; }
        .user-info span { color: white; font-weight: 600; }
        .navbar { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1); }
        .navbar ul { display: flex; list-style: none; justify-content: center; padding: 0; margin: 0; }
        .navbar a { display: block; padding: 20px 30px; text-decoration: none; color: #333; font-weight: 600; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; transition: all 0.3s ease; }
        .navbar a:hover { color: #e94560; background: rgba(233, 69, 96, 0.05); }
        .container { max-width: 1200px; margin: 50px auto; padding: 0 20px; }
        .page-header { background: white; border-radius: 20px; padding: 40px; margin-bottom: 30px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); position: relative; overflow: hidden; }
        .page-header::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 5px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); }
        .page-header h2 { color: #1a1a2e; font-size: 32px; margin-bottom: 10px; }
        .date-filter { background: white; border-radius: 20px; padding: 30px; margin-bottom: 30px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); display: flex; gap: 15px; align-items: flex-end; }
        .date-filter label { color: #333; font-weight: 600; font-size: 14px; }
        .date-filter input { padding: 14px 18px; border: 2px solid #e0e0e0; border-radius: 12px; font-size: 15px; }
        .date-filter input:focus { outline: none; border-color: #e94560; }
        .date-filter button { padding: 14px 30px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); color: white; border: none; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; }
        .date-filter button:hover { transform: translateY(-3px); box-shadow: 0 10px 30px rgba(233, 69, 96, 0.4); }
        .data-table { width: 100%; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); }
        .data-table thead { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; }
        .data-table th { padding: 20px; text-align: left; font-weight: 600; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; }
        .data-table td { padding: 18px 20px; border-bottom: 1px solid #f0f0f0; color: #333; }
        .data-table tbody tr { transition: all 0.3s ease; }
        .data-table tbody tr:hover { background: rgba(233, 69, 96, 0.05); }
        .amount { font-weight: 700; color: #28a745 !important; }
        .total-row { background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); color: white; }
        .total-row td { border-bottom: none; }
        .print-btn { padding: 14px 30px; background: #28a745; color: white; border: none; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>📊 Daily Reports</h1>
        <div class="user-info">
            <div class="avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </div>
    <nav class="navbar">
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="car.php">Car</a></li>
            <li><a href="package.php">Packages</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="page-header">
            <h2>📊 Daily Sales Report</h2>
            <p>View and analyze your daily transactions</p>
        </div>
        <form method="GET" action="" class="date-filter">
            <div>
                <label>Select Date:</label><br>
                <input type="date" name="date" value="<?php echo $date; ?>">
            </div>
            <button type="submit">Generate Report</button>
        </form>
        <h3 style="color: #1a1a2e; margin-bottom: 20px; font-size: 20px;">Report for <?php echo $date; ?></h3>
        <table class="data-table">
            <thead><tr><th>Plate Number</th><th>Package Name</th><th>Description</th><th>Amount (RWF)</th><th>Payment Date</th></tr></thead>
            <tbody>
                <?php
                $total = 0;
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['PlateNumber'] . "</td>";
                    echo "<td>" . $row['PackageName'] . "</td>";
                    echo "<td>" . $row['PackageDescription'] . "</td>";
                    echo "<td class='amount'>" . number_format($row['AmountPaid']) . "</td>";
                    echo "<td>" . $row['PaymentDate'] . "</td>";
                    echo "</tr>";
                    $total += $row['AmountPaid'];
                }
                ?>
                <tr class="total-row">
                    <td colspan="3"><strong>Total:</strong></td>
                    <td class="amount"><strong><?php echo number_format($total); ?> RWF</strong></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        <button class="print-btn" onclick="window.print()">🖨️ Print Report</button>
    </div>
</body>
</html>

