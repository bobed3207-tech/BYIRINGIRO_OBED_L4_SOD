<?php
session_start();
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
require_once 'config/db.php';

if(isset($_POST['submit'])) {
    $plate = mysqli_real_escape_string($conn, $_POST['plate']);
    $package = mysqli_real_escape_string($conn, $_POST['package']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    
    $query = "INSERT INTO ServicePackage (PlateNumber, PackageNumber, ServiceDate) VALUES ('$plate', '$package', '$date')";
    if(mysqli_query($conn, $query)) {
        $success = "Service record created";
    }
}

if(isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM ServicePackage WHERE RecordNumber=$id");
}

if(isset($_POST['update'])) {
    $id = $_POST['record_id'];
    $plate = $_POST['plate'];
    $package = $_POST['package'];
    $date = $_POST['date'];
    $query = "UPDATE ServicePackage SET PlateNumber='$plate', PackageNumber='$package', ServiceDate='$date' WHERE RecordNumber=$id";
    mysqli_query($conn, $query);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Management - Car Wash System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { min-height: 100vh; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); }
        .header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); padding: 25px 50px; color: white; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 24px; font-weight: 700; }
        .user-info { display: flex; align-items: center; gap: 10px; }
        .user-info .avatar { width: 40px; height: 40px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; }
        .user-info span { color: white; font-weight: 600; }
        .navbar { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1); }
        .navbar ul { display: flex; list-style: none; justify-content: center; padding: 0; margin: 0; }
        .navbar a { display: block; padding: 20px 30px; text-decoration: none; color: #333; font-weight: 600; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; transition: all 0.3s ease; }
        .navbar a:hover { color: #e94560; background: rgba(233, 69, 96, 0.05); }
        .container { max-width: 1200px; margin: 50px auto; padding: 0 20px; }
        .page-header { background: white; border-radius: 20px; padding: 40px; margin-bottom: 30px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); position: relative; overflow: hidden; }
        .page-header::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 5px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); }
        .page-header h2 { color: #1a1a2e; font-size: 32px; margin-bottom: 10px; }
        .form-card { background: white; border-radius: 20px; padding: 35px; margin-bottom: 30px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); }
        .form-card h3 { color: #1a1a2e; font-size: 20px; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; color: #333; font-size: 13px; font-weight: 600; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
        .form-group input, .form-group select { width: 100%; padding: 14px 18px; border: 2px solid #e0e0e0; border-radius: 12px; font-size: 15px; transition: all 0.3s ease; background: #f8f9fa; }
        .form-group input:focus, .form-group select:focus { outline: none; border-color: #e94560; background: #fff; box-shadow: 0 0 0 4px rgba(233, 69, 96, 0.1); }
        button[type="submit"] { padding: 16px 35px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); color: white; border: none; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; text-transform: uppercase; letter-spacing: 1px; box-shadow: 0 5px 20px rgba(233, 69, 96, 0.3); }
        button[type="submit"]:hover { transform: translateY(-3px); box-shadow: 0 10px 30px rgba(233, 69, 96, 0.4); }
        .success { background: #d4edda; color: #155724; padding: 16px; border-radius: 12px; margin-bottom: 25px; border-left: 4px solid #28a745; }
        .data-table { width: 100%; background: white; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); }
        .data-table thead { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; }
        .data-table th { padding: 20px; text-align: left; font-weight: 600; font-size: 13px; text-transform: uppercase; letter-spacing: 1px; }
        .data-table td { padding: 18px 20px; border-bottom: 1px solid #f0f0f0; color: #333; }
        .data-table tbody tr { transition: all 0.3s ease; }
        .data-table tbody tr:hover { background: rgba(233, 69, 96, 0.05); }
        .btn-edit { padding: 8px 16px; background: #0f3460; color: white; text-decoration: none; border-radius: 8px; font-size: 12px; margin-right: 5px; }
        .btn-delete { padding: 8px 16px; background: #e94560; color: white; text-decoration: none; border-radius: 8px; font-size: 12px; }
        .edit-form { background: #f8f9fa; padding: 25px; border-radius: 15px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚿 Service Management</h1>
        <div class="user-info">
            <div class="avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </div>
    <nav class="navbar">
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="car.php">Car</a></li>
            <li><a href="package.php">Packages</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="page-header">
            <h2>🚿 Service Package Management</h2>
            <p>Create and manage service records</p>
        </div>
        <?php if(isset($success)) echo "<div class='success'>$success</div>"; ?>
        <div class="form-card">
            <h3>Create New Service</h3>
            <form method="POST" action="">
                <div class="form-group">
                    <label>Car:</label>
                    <select name="plate" required>
                        <?php $cars = mysqli_query($conn, "SELECT * FROM Car"); while($car = mysqli_fetch_assoc($cars)) { echo "<option value='".$car['PlateNumber']."'>".$car['PlateNumber']." - ".$car['DriverName']."</option>"; } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Package:</label>
                    <select name="package" required>
                        <?php $packages = mysqli_query($conn, "SELECT * FROM Package"); while($pkg = mysqli_fetch_assoc($packages)) { echo "<option value='".$pkg['PackageNumber']."'>".$pkg['PackageName']." - ".$pkg['PackagePrice']." RWF</option>"; } ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Service Date:</label>
                    <input type="date" name="date" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                <button type="submit" name="submit">Create Service Record</button>
            </form>
        </div>
        <h3 style="color: #1a1a2e; margin-bottom: 20px; font-size: 24px;">Service Records</h3>
        <table class="data-table">
            <thead><tr><th>Record #</th><th>Plate</th><th>Package</th><th>Date</th><th>Actions</th></tr></thead>
            <tbody>
                <?php
                $result = mysqli_query($conn, "SELECT sp.*, p.PackageName, p.PackagePrice FROM ServicePackage sp JOIN Package p ON sp.PackageNumber = p.PackageNumber");
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['RecordNumber'] . "</td>";
                    echo "<td>" . $row['PlateNumber'] . "</td>";
                    echo "<td>" . $row['PackageName'] . " (" . $row['PackagePrice'] . " RWF)</td>";
                    echo "<td>" . $row['ServiceDate'] . "</td>";
                    echo "<td><a href='?edit=".$row['RecordNumber']."' class='btn-edit'>Edit</a><a href='?delete=".$row['RecordNumber']."' class='btn-delete' onclick='return confirm(\"Delete?\")'>Delete</a></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <?php if(isset($_GET['edit'])): $edit_id = $_GET['edit']; $edit_data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM ServicePackage WHERE RecordNumber=$edit_id")); ?>
        <div class="edit-form">
            <h3>Edit Record #<?php echo $edit_id; ?></h3>
            <form method="POST" action="">
                <input type="hidden" name="record_id" value="<?php echo $edit_id; ?>">
                <div class="form-group"><label>Car:</label><select name="plate"><?php $cars = mysqli_query($conn, "SELECT * FROM Car"); while($car = mysqli_fetch_assoc($cars)) { $selected = ($car['PlateNumber'] == $edit_data['PlateNumber']) ? 'selected' : ''; echo "<option value='".$car['PlateNumber']."' $selected>".$car['PlateNumber']."</option>"; } ?></select></div>
                <div class="form-group"><label>Package:</label><select name="package"><?php $packages = mysqli_query($conn, "SELECT * FROM Package"); while($pkg = mysqli_fetch_assoc($packages)) { $selected = ($pkg['PackageNumber'] == $edit_data['PackageNumber']) ? 'selected' : ''; echo "<option value='".$pkg['PackageNumber']."' $selected>".$pkg['PackageName']."</option>"; } ?></select></div>
                <div class="form-group"><label>Date:</label><input type="date" name="date" value="<?php echo $edit_data['ServiceDate']; ?>"></div>
                <button type="submit" name="update">Update</button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>

