<?php
session_start();
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
require_once 'config/db.php';

if(isset($_POST['submit'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $desc = mysqli_real_escape_string($conn, $_POST['desc']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    
    $query = "INSERT INTO Package (PackageName, PackageDescription, PackagePrice) VALUES ('$name', '$desc', '$price')";
    if(mysqli_query($conn, $query)) {
        $success = "Package added successfully";
    } else {
        $error = "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Package Management - Car Wash System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Poppins', sans-serif; }
        body { min-height: 100vh; background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); }
        .header { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); padding: 25px 50px; color: white; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); display: flex; justify-content: space-between; align-items: center; }
        .header h1 { font-size: 24px; font-weight: 700; }
        .user-info { display: flex; align-items: center; gap: 10px; }
        .user-info .avatar { width: 40px; height: 40px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 600; }
        .user-info span { color: white; font-weight: 600; }
        .navbar { background: rgba(255, 255, 255, 0.95); backdrop-filter: blur(10px); box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1); }
        .navbar ul { display: flex; list-style: none; justify-content: center; padding: 0; margin: 0; }
        .navbar a { display: block; padding: 20px 30px; text-decoration: none; color: #333; font-weight: 600; font-size: 14px; text-transform: uppercase; letter-spacing: 1px; transition: all 0.3s ease; }
        .navbar a:hover { color: #e94560; background: rgba(233, 69, 96, 0.05); }
        .container { max-width: 1200px; margin: 50px auto; padding: 0 20px; }
        .page-header { background: white; border-radius: 20px; padding: 40px; margin-bottom: 30px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); position: relative; overflow: hidden; }
        .page-header::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 5px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); }
        .page-header h2 { color: #1a1a2e; font-size: 32px; margin-bottom: 10px; }
        .form-card { background: white; border-radius: 20px; padding: 35px; margin-bottom: 30px; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1); }
        .form-card h3 { color: #1a1a2e; font-size: 20px; margin-bottom: 25px; padding-bottom: 15px; border-bottom: 2px solid #f0f0f0; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; color: #333; font-size: 13px; font-weight: 600; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
        .form-group input, .form-group textarea { width: 100%; padding: 14px 18px; border: 2px solid #e0e0e0; border-radius: 12px; font-size: 15px; transition: all 0.3s ease; background: #f8f9fa; }
        .form-group input:focus, .form-group textarea:focus { outline: none; border-color: #e94560; background: #fff; box-shadow: 0 0 0 4px rgba(233, 69, 96, 0.1); }
        button[type="submit"] { padding: 16px 35px; background: linear-gradient(135deg, #e94560 0%, #0f3460 100%); color: white; border: none; border-radius: 12px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s ease; text-transform: uppercase; letter-spacing: 1px; box-shadow: 0 5px 20px rgba(233, 69, 96, 0.3); }
        button[type="submit"]:hover { transform: translateY(-3px); box-shadow: 0 10px 30px rgba(233, 69, 96, 0.4); }
        .success { background: #d4edda; color: #155724; padding: 16px; border-radius: 12px; margin-bottom: 25px; border-left: 4px solid #28a745; }
        .error { background: #f8d7da; color: #721c24; padding: 16px; border-radius: 12px; margin-bottom: 25px; border-left: 4px solid #dc3545; }
    </style>
</head>
<body>
    <div class="header">
        <h1>📦 Package Management</h1>
        <div class="user-info">
            <div class="avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </div>
    <nav class="navbar">
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="car.php">Car</a></li>
            <li><a href="package.php">Packages</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="container">
        <div class="page-header">
            <h2>📦 Add New Package</h2>
            <p>Create pricing packages for your car wash services</p>
        </div>
        <?php if(isset($success)) echo "<div class='success'>$success</div>"; ?>
        <?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>
        <div class="form-card">
            <h3>Package Details</h3>
            <form method="POST" action="">
                <div class="form-group">
                    <label>Package Name *</label>
                    <input type="text" name="name" placeholder="e.g. Premium Wash" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="desc" rows="3" placeholder="Describe what's included in this package"></textarea>
                </div>
                <div class="form-group">
                    <label>Price (RWF) *</label>
                    <input type="number" name="price" step="0.01" min="0" placeholder="e.g. 5000" required>
                </div>
                <button type="submit" name="submit">Save Package</button>
            </form>
        </div>
    </div>
</body>
</html>

