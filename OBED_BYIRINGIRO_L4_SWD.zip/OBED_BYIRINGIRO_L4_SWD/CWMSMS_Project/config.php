<?php
session_start();

$host = "localhost";
$user = "root";          // ← change if different
$pass = "";              // ← change if different
$dbname = "CWMSMS";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>