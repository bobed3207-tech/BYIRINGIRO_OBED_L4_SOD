<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CWMSMS - Car Wash Management</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <nav>
        <a href="dashboard.php">Home</a> |
        <a href="car.php">Cars</a> |
        <a href="package.php">Packages</a> |
        <a href="service.php">Services</a> |
        <a href="reports.php">Reports</a> |
        <a href="logout.php" style="color:#e74c3c;">Logout</a>
    </nav>

    <div class="container">