<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "CWSSMS";

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Optional: Create Users table for login
// Run this once to create admin user
$create_users = "CREATE TABLE IF NOT EXISTS Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255)
)";
mysqli_query($conn, $create_users);

// Insert default admin (password: admin123)
// In production, use password_hash()
$check_admin = mysqli_query($conn, "SELECT * FROM Users WHERE username='admin'");
if(mysqli_num_rows($check_admin) == 0) {
    mysqli_query($conn, "INSERT INTO Users (username, password) VALUES ('admin', 'admin123')");
}
?>