-- Create database
CREATE DATABASE CWSSMS;
USE CWSSMS;

-- Create Car table
CREATE TABLE Car (
    PlateNumber VARCHAR(20) PRIMARY KEY,
    CarType VARCHAR(50),
    CarSize VARCHAR(20),
    DriverName VARCHAR(100),
    PhoneNumber VARCHAR(15)
);

-- Create Package table
CREATE TABLE Package (
    PackageNumber INT AUTO_INCREMENT PRIMARY KEY,
    PackageName VARCHAR(50),
    PackageDescription TEXT,
    Price DECIMAL(10, 2)
);

-- Insert package data
INSERT INTO Package (PackageName, PackageDescription, Price) VALUES
('Banner dash', 'Exterior hand wash', 5000),
('Closer wash', 'Interior hand wash', 10000),
('Premium wash', 'Exterior and Interior hand wash', 20000);

-- Create ServicePackage table
CREATE TABLE ServicePackage (
    RecordNumber INT AUTO_INCREMENT PRIMARY KEY,
    PlateNumber VARCHAR(20),
    PackageNumber INT,
    ServiceDate DATE,
    FOREIGN KEY (PlateNumber) REFERENCES Car(PlateNumber) ON DELETE CASCADE,
    FOREIGN KEY (PackageNumber) REFERENCES Package(PackageNumber) ON DELETE CASCADE
);

-- Create Payment table
CREATE TABLE Payment (
    PaymentNumber INT AUTO_INCREMENT PRIMARY KEY,
    RecordNumber INT UNIQUE,
    AmountPaid DECIMAL(10, 2),
    PaymentDate DATE,
    FOREIGN KEY (RecordNumber) REFERENCES ServicePackage(RecordNumber) ON DELETE CASCADE
);