<?php
session_start();
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
require_once 'config/db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Car Wash System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        
        body {
            min-height: 100vh;
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
        }
        
        .header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            padding: 25px 50px;
            color: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 700;
            letter-spacing: 1px;
        }
        
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 0;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .navbar ul {
            display: flex;
            list-style: none;
            justify-content: center;
            padding: 0;
            margin: 0;
        }
        
        .navbar li {
            position: relative;
        }
        
        .navbar a {
            display: block;
            padding: 20px 30px;
            text-decoration: none;
            color: #333;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            position: relative;
        }
        
        .navbar a::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            width: 0;
            height: 3px;
            background: linear-gradient(135deg, #e94560 0%, #0f3460 100%);
            transition: all 0.3s ease;
            transform: translateX(-50%);
        }
        
        .navbar a:hover {
            color: #e94560;
            background: rgba(233, 69, 96, 0.05);
        }
        
        .navbar a:hover::after {
            width: 100%;
        }
        
        .container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 0 20px;
        }
        
        .welcome-section {
            background: white;
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 40px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            position: relative;
            overflow: hidden;
        }
        
        .welcome-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(135deg, #e94560 0%, #0f3460 100%);
        }
        
        .welcome-section h2 {
            color: #1a1a2e;
            font-size: 32px;
            margin-bottom: 10px;
        }
        
        .welcome-section p {
            color: #666;
            font-size: 16px;
        }
        
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
        }
        
        .card {
            background: white;
            border-radius: 20px;
            padding: 35px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(233,69,96,0.05) 0%, rgba(15,52,96,0.05) 100%);
            opacity: 0;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
        }
        
        .card:hover::before {
            opacity: 1;
        }
        
        .card h3 {
            color: #666;
            font-size: 14px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 15px;
        }
        
        .card .icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #e94560 0%, #0f3460 100%);
            border-radius: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(233, 69, 96, 0.3);
        }
        
        .card p {
            color: #1a1a2e;
            font-size: 36px;
            font-weight: 700;
        }
        
        .quick-actions {
            margin-top: 40px;
        }
        
        .quick-actions h3 {
            color: #1a1a2e;
            font-size: 24px;
            margin-bottom: 25px;
        }
        
        .action-buttons {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 15px 30px;
            background: linear-gradient(135deg, #e94560 0%, #0f3460 100%);
            color: white;
            text-decoration: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 5px 20px rgba(233, 69, 96, 0.3);
        }
        
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(233, 69, 96, 0.4);
        }
        
        .user-info {
            position: absolute;
            top: 25px;
            right: 50px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .user-info .avatar {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #e94560 0%, #0f3460 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
        }
        
        .user-info span {
            color: white;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🚗 Car Wash Sales Management System</h1>
        <div class="user-info">
            <div class="avatar"><?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?></div>
            <span><?php echo $_SESSION['username']; ?></span>
        </div>
    </div>
    
    <nav class="navbar">
        <ul>
            <li><a href="dashboard.php">Home</a></li>
            <li><a href="car.php">Car</a></li>
            <li><a href="package.php">Packages</a></li>
            <li><a href="service.php">Services</a></li>
            <li><a href="reports.php">Reports</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    
    <div class="container">
        <div class="welcome-section">
            <h2>Welcome back, <?php echo $_SESSION['username']; ?>! 👋</h2>
            <p>Here's what's happening with your car wash business today.</p>
        </div>
        
        <div class="dashboard-cards">
            <div class="card">
                <div class="icon">🚿</div>
                <h3>Total Services Today</h3>
                <p>0</p>
            </div>
            <div class="card">
                <div class="icon">💰</div>
                <h3>Today's Revenue</h3>
                <p>0 RWF</p>
            </div>
            <div class="card">
                <div class="icon">🚗</div>
                <h3>Cars Registered</h3>
                <p>0</p>
            </div>
            <div class="card">
                <div class="icon">📦</div>
                <h3>Active Packages</h3>
                <p>0</p>
            </div>
        </div>
        
        <div class="quick-actions">
            <h3>Quick Actions</h3>
            <div class="action-buttons">
                <a href="car.php" class="action-btn">Register New Car</a>
                <a href="package.php" class="action-btn">Add Package</a>
                <a href="service.php" class="action-btn">Create Service</a>
                <a href="reports.php" class="action-btn">View Reports</a>
            </div>
        </div>
    </div>
</body>
</html>

